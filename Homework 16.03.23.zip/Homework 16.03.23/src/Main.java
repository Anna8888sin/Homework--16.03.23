import java.lang.invoke.StringConcatException;
import java.util.StringJoiner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Проект 1");
        byte b = 1;
        short s = b;
        int i = s;
        long l = i;
        double d = l;
        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(l);

        System.out.println();
        System.out.println();
        System.out.println("Проект 2");
        long lo = 1000l;
        byte n = (byte) lo;
        short ne = (short) lo;
        int nes = (int) lo;
        double news = (double) lo;
        System.out.println(n);
        System.out.println(ne);
        System.out.println(nes);
        System.out.println(news);

        System.out.println();
        System.out.println();

        System.out.println("Проект 3");
        String str = "I study Basic Java!";
        System.out.println(str.charAt(0));
        System.out.println(str.charAt(str.length() -1));
        String substring ="Java";
        System.out.println(substring);
        String value = "I study Basic Java!".replace("a", "o");
        System.out.println(value);
        String strUpper = str.toUpperCase();
        
        System.out.println(strUpper);
        String strLover = str.toLowerCase();
        System.out.println(strLover);

        System.out.println(str.substring( 13, 18));






    }
}